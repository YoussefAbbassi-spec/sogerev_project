const ContactItem = ({ Icon, title, value }) => (
  <div className="flex items-center gap-2">
    <div
      className="w-8 h-8 rounded-full border-2 flex items-center justify-center flex-shrink-0"
      style={{ borderColor: "var(--color-primary)" }}
    >
      <Icon size={14} style={{ color: "var(--color-primary)" }} />
    </div>
    <div>
      <div className="font-bold text-xs text-gray-900">{title}</div>
      <div className="text-xs text-gray-500">{value}</div>
    </div>
  </div>
);

export default ContactItem;
