import { useState } from "react";
import {
  Phone,
  ChevronLeft,
  ChevronRight,
  MoveRight,
  Instagram,
  Facebook,
  Youtube,
} from "lucide-react";
import SocialBtn from "../SocialBtn/SocialBtn";
import { TikTokIcon, WhatsAppIcon } from "../Icons/Icons";
import { SLIDES, SOCIAL_LINKS, HERO_CTAS } from '../../constants/Hero_data';

// Map social id to its icon component
const SOCIAL_ICONS = {
  instagram: Instagram,
  facebook: Facebook,
  tiktok: TikTokIcon,
  youtube: Youtube,
  whatsapp: WhatsAppIcon,
};

const HeroSlider = () => {
  const [current, setCurrent] = useState(0);

  const prev = () =>
    setCurrent((c) => (c === 0 ? SLIDES.length - 1 : c - 1));
  const next = () =>
    setCurrent((c) => (c === SLIDES.length - 1 ? 0 : c + 1));

  const slide = SLIDES[current];

  return (
    <section className="relative w-full h-[480px] md:h-[620px] overflow-hidden" style={{ marginBottom: '50px' }}>

      {/* ── BACKGROUND ── */}
      <div className="absolute inset-0">
        {slide.heroImage ? (
          <img
            src={slide.heroImage}
            alt=""
            className="w-full h-full"
            style={{
              objectFit: "fill",
            }}
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-gray-900 via-gray-800 to-gray-700" />
        )}
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-black/55" />
      </div>

      {/* ── SLIDE CONTENT ── */}
      <div className="relative z-10 h-full flex flex-col justify-end pb-10 px-6 md:px-16">
        <div className="max-w-xl">
          <h1 className="text-white font-black text-2xl md:text-4xl leading-tight mb-4 uppercase" style={{ fontFamily: 'SemiExpanded Regular' }}>
            {slide.heroTitle}
          </h1>
          <p className="text-gray-300 text-sm md:text-base mb-6">
            {slide.heroSubTitle}
          </p>

          {/* Social row */}
          <p className="text-white font-bold text-sm tracking-widest mb-3">
            SUIVEZ-NOUS :
          </p>
          <div className="flex items-center gap-3">
            <div
              className="w-9 h-9 rounded-full border-2 flex items-center justify-center flex-shrink-0"
              style={{
                backgroundColor: "#ffffff",
                color: "var(--color-primary)",
                borderRadius: "0px",
                border: "none",
              }}

            >
              <Phone size={14} style={{ color: "var(--color-primary)" }} />
            </div>
            <div className="w-16 h-px bg-white/40" />
            {SOCIAL_LINKS.map((social) => {
              const Icon = SOCIAL_ICONS[social.id];
              return (
                <SocialBtn key={social.id} href={social.href}>
                  <Icon size={16} />
                </SocialBtn>
              );
            })}
          </div>
        </div>
      </div>

      {/* ── DESKTOP SIDE CTAs — white solid background ── */}
      <div className="hidden md:flex absolute right-8 bottom-16 flex-col gap-3 z-10">
        {HERO_CTAS.map((cta) => (
          <a
            key={cta.id}
            href={cta.href}
            className="flex min-w-[220px] items-center gap-3 bg-white text-gray-800 px-5 py-3 rounded text-sm font-semibold hover:bg-gray-100 transition-all shadow-md"
          >
            <span
              className="w-2 h-2 rounded-full flex-shrink-0"
              style={{ backgroundColor: "gray" }}
            />
            {/* {cta.label} */}
            <span className="flex-1" style={{ color: 'gray' }}>{cta.label}</span>
            <MoveRight size={16} style={{ color: "var(--color-primary)", }} />
          </a>
        ))}
      </div>

      {/* ── ARROWS ── */}
      <button
        onClick={prev}
        className="absolute left-3 top-1/7 -translate-y-1/2 z-10 flex items-center justify-center text-white transition-all hover:opacity-70"
        aria-label="Slide précédent"
      >
        <ChevronLeft size={86} strokeWidth={1} />
      </button>

      <button
        onClick={next}
        className="absolute right-3 top-1/6 -translate-y-1/2 z-10 flex items-center justify-center text-white transition-all hover:opacity-70"
        aria-label="Slide suivant"
      >
        <ChevronRight size={86} strokeWidth={1} />
      </button>

      {/* ── DOTS — inside curved white shape ── */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 z-10">
        {/* Curved white container */}
        <div
          className="flex items-center justify-center gap-2 px-8 pt-5 pb-2"
          style={{
            backgroundColor: "#ffffffff",
            borderRadius: "900px 900px 0px 0",   /* ← courbe en haut, plat en bas */
            minWidth: "600px",
          }}
        >
          {SLIDES.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrent(i)}
              aria-label={`Slide ${i + 1}`}
              className="h-1.5 rounded-full transition-all duration-300"
              style={{
                backgroundColor: i === current ? "black" : "rgba(0,0,0,0.2)",
                width: i === current ? "24px" : "8px",
              }}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default HeroSlider;

