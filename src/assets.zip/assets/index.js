



import SLIDE_1 from "./images/slide-1.jpg";
// import SLIDE_2 from "./images/slide-2.jpg";
// import SLIDE_3 from "./images/slide-3.jpg";

// import PDF_MDF_MEDELACK from "./pdfs/mdf-medelack-logimar.pdf";
// import PDF_MDF_COLOR     from "./pdfs/mdf-color.pdf";
// import PDF_MDF_LOGIMAR   from "./pdfs/mdf-logimar.pdf";
// import PDF_NEW_MDF       from "./pdfs/new-mdf-logimar.pdf";

import LOGO from "./images/logo_.png";
import buildingImg from "./images/Building.png";
import cubeImg from "./images/Cube.png";



export const ASSETS = {
    IMAGES: {
        SLIDE_1,
        SLIDE_1,
        SLIDE_1,
        SLIDE_1
    },
    ICONS: {

    },
    PDFS: {
        MDF_MEDELACK: null,
        MDF_COLOR: null,
        MDF_LOGIMAR: null,
        NEW_MDF: null,
    },
    LOGO,
    buildingImg,
    cubeImg
}